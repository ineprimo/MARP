# Carpeta `aplicaciones`

Contiene los ejemplos relativos al tema *Aplicaciones de Tipos Abstractos de Datos*

## Implementaciones del TAD Academia

* `academia_v1`: Implementación inicial.
* `academia_v2`: Implementación con registro de estudiantes.
* `academia_v2`: Implementación con registro de estudiantes y listas de espera en cursos.

## Implementación del TAD Metro

* `metro_v1`: Versión inicial.
* `metro_v2`: Versión alternativa.