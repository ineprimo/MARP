/*
 * ---------------------------------------------------
 *                ESTRUCTURAS DE DATOS
 * ---------------------------------------------------
 *              Manuel Montenegro Montes
 *              Facultad de Informática
 *         Universidad Complutense de Madrid
 * ---------------------------------------------------
 */

/*
 * Uso de la clase Persona, con destructor.
 */

#include "Persona.h"

int main() {
  Persona p("David", 15, 3, 1979);
  return 0;
}