/*
 * ---------------------------------------------------
 *                ESTRUCTURAS DE DATOS
 * ---------------------------------------------------
 *              Manuel Montenegro Montes
 *              Facultad de Informática
 *         Universidad Complutense de Madrid
 * ---------------------------------------------------
 */

/*
 * Uso de la clase Persona.
 */

#include "Persona.h"

int main() {
  Persona p("Manuel", 28, 8, 1983);

  return 0;
}