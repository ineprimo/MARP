# Carpeta `juego_letras`

Versión sin encapsulación del juego de adivinar letras.

En Linux o en Windows con MinGW, ejecutar `make` para compilar los ficheros.

