# Carpeta `intro`

Contiene los ejemplos relativos a la introducción a los Tipos Abstractos de DAtos.

## Implementaciones

 * `juego_letras`: Juego de letras sin encapsulación.
 * `juego_letras_struct`: TAD ConjuntoChar utilizando encapsulación mediante structs.
 * `juego_letras_clases`: TAD ConjuntoChar utilizando encapsulación mediante clases de C++.
