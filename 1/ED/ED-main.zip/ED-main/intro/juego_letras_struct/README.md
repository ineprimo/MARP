# Carpeta `juego_letras_struct`

Implementación de un tipo abstracto de datos mediante los `struct` de C++.

En Linux o en Windows con MinGW, ejecutar `make` para compilar los ficheros.

Ficheros disponibles:

 * `ConjuntoCharArray.h`: Versión del TAD que utiliza un array de caracteres.
 * `ConjuntoCharBool.h`: Versión del TAD que utiliza un array de booleanos.
 * `juego.cpp`: Versión con encapsulación.
