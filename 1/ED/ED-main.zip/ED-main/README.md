# Estructuras de Datos. Curso 2023/24

**Grado en Ingeniería Informática**

**Grado en Ingeniería del Software**

**Grado en Ingeniería de Computadores**

**Facultad de Informática (Universidad Complutense de Madrid)**


En este repositorio encontrarás el código fuente de los ejemplos y tipos abstractos de datos vistos en clase. Para más información consulta el espacio de la asignatura en el [Campus Virtual](https://www.ucm.es/campusvirtual) de la UCM.

